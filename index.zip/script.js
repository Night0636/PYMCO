document.addEventListener('DOMContentLoaded', function() {
    const categories = ['casas', 'chimenea', 'suelo', 'iluminacion', 'cocina', 'paredes', 'bano', 'jardin', 'puertas', 'ventanas', 'muebles', 'invitados'];
    let currentIndex = 0;
    const selections = {};
  
    function showCategory(categoryIndex) {
      document.querySelectorAll('.menu-item').forEach(item => {
        item.style.display = 'none';
      });
  
      const currentCategory = categories[categoryIndex];
      document.querySelectorAll(`.menu-item#${currentCategory}`).forEach(item => {
        item.style.display = 'block';
      });
  
      const title = document.getElementById('customization-title');
      title.innerText = `Personalizar ${currentCategory.replace(/^\w/, c => c.toUpperCase())}`;
    }
  
    function handleItemClick(event) {
      const selectedCategory = categories[currentIndex];
      const selectedOption = event.currentTarget.querySelector('p').innerText;
      selections[selectedCategory] = selectedOption;
      currentIndex++;
  
      if (currentIndex === categories.length) {
        showRecords();
      } else {
        showCategory(currentIndex);
      }
    }
  
    function showRecords() {
      const recordsContainer = document.createElement('div');
      recordsContainer.classList.add('records-container');
  
      for (const category in selections) {
        const recordItem = document.createElement('p');
        recordItem.innerText = `${category}: ${selections[category]}`;
        recordsContainer.appendChild(recordItem);
      }
  
      document.body.appendChild(recordsContainer);
    }
  
    document.querySelectorAll('.menu-item').forEach(item => {
      item.addEventListener('click', handleItemClick);
    });
  
    showCategory(currentIndex);
  });
  